using UnityEngine;

public class GameManager : MonoBehaviour
{
    public PuzzlePiece[] pieces;
    public GameObject winPanel; // ← вместо winText

    private bool isWin = false;

    void Update()
    {
        if (isWin) return;

        foreach (var piece in pieces)
        {
            if (!piece.IsPlaced())
                return;
        }

        isWin = true;

        Debug.Log("YOU WIN!");
        winPanel.SetActive(true); // ← включаем весь экран
    }
}