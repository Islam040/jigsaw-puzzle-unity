using UnityEngine;

public class DragManager : MonoBehaviour
{
    private PuzzlePiece selectedPiece;
    private Vector3 offset;

    void Update()
    {
        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // НАЖАЛ ПКМ
        if (Input.GetMouseButtonDown(1))
        {
            RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

            if (hit.collider != null)
            {
                selectedPiece = hit.collider.GetComponent<PuzzlePiece>();

                if (selectedPiece != null && !selectedPiece.IsPlaced())
                {
                    Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                    worldPos.z = 0;
                    offset = selectedPiece.transform.position - worldPos;
                }
                else
                {
                    selectedPiece = null;
                }
            }
        }

        // ТАЩИМ
        if (Input.GetMouseButton(1) && selectedPiece != null)
        {
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            worldPos.z = 0;

            selectedPiece.transform.position = worldPos + offset;
        }

        // ОТПУСТИЛ
        if (Input.GetMouseButtonUp(1) && selectedPiece != null)
        {
            float dist = Vector3.Distance(selectedPiece.transform.position, selectedPiece.correctPosition);

            if (dist < 0.7f)
            {
                selectedPiece.transform.position = selectedPiece.correctPosition;
                selectedPiece.transform.rotation = Quaternion.identity;
                selectedPiece.SetPlaced(true);

                Debug.Log("Placed!");
            }

            selectedPiece = null;
        }
    }
}