using UnityEngine;

public class PuzzlePiece : MonoBehaviour
{
    public Vector3 correctPosition;
    private bool isPlaced = false;

    private Vector3 offset;
    private bool isDragging = false;

    void Start()
    {
        correctPosition = transform.position;

        float randomX = Random.Range(-5f, 5f);
        float randomY = Random.Range(-5f, 5f);
        transform.position = new Vector3(randomX, randomY, 0);
    }

    void OnMouseDown()
    {
        
        // 👉 только ПКМ
        if (!Input.GetMouseButton(1)) return;

        if (isPlaced) return;

        Debug.Log("RIGHT CLICK TAKE");

        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10f;
        mousePos = Camera.main.ScreenToWorldPoint(mousePos);

        offset = transform.position - new Vector3(mousePos.x, mousePos.y, 0);
        isDragging = true;
    }

    void OnMouseDrag()
    {
        if (!isDragging || isPlaced) return;

        Vector3 mousePos = Input.mousePosition;
        mousePos.z = 10f;
        mousePos = Camera.main.ScreenToWorldPoint(mousePos);

        transform.position = new Vector3(mousePos.x, mousePos.y, 0) + offset;
    }

    void OnMouseUp()
    {
        if (!isDragging) return;

        isDragging = false;

        float distance = Vector3.Distance(transform.position, correctPosition);

        if (distance < 0.7f)
        {
            transform.position = correctPosition;
            transform.rotation = Quaternion.identity;
            isPlaced = true;

            Debug.Log("Placed!");
        }
    }

    public bool IsPlaced()
    {
        return isPlaced;
    }

    public void SetPlaced(bool value)
    {
        isPlaced = value;
    }
}